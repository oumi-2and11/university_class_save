#!/usr/bin/env python3

import logging

logging.basicConfig(level= logging.INFO,
                    format = '%(asctime)s - %(message)s')

logger = logging.getLogger(__name__)

